# microxanox 0.3.0 **NOT COMPATIBLE WITH PREVIOUS VERSION**

* Introduces new parameter format which does not use global variables anymore. This enables saving of parameter in a single file by using `saveRDS()`.

* Added a `NEWS.md` file to track changes to the package.

# microxanox 0.2.2
 * Last version using global parameter