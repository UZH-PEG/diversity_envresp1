## ----setup, echo = FALSE, output = FALSE, message = FALSE---------------------
## should some of the more intense simulations be run...

options(mc.cores=8)

mdat <- function(name = "") {
  system.file(file.path("data_pkg", "user_guide", name), package = "microxanox")
}

##########
### To generate the data_pkg, please uncomment the following three lines.
# 
# mdat <- function(name = "") {
#   file.path(".", "data_pkg", "user_guide", name)
# }
# dir.create(mdat(), recursive = TRUE, showWarnings = FALSE)
##########


knitr::opts_chunk$set(
  cache = FALSE,
  fig.align = "centre", 
  fig.width = 7, 
  fig.height = 7
)


library(tidyverse)
library(deSolve)
library(rootSolve)
library(microxanox)
library(patchwork)

## Set random number generator seed
## Is redundant if there are no stochastic components in the model
set.seed(13)


## -----------------------------------------------------------------------------
packageVersion("microxanox")

## -----------------------------------------------------------------------------
new_runsim_parameter()

## -----------------------------------------------------------------------------
new_runsim_parameter(dynamic_model = bushplus_dynamic_model)

## -----------------------------------------------------------------------------
parameter_set1 <- new_runsim_parameter()
parameter_set1$dynamic_model <- bushplus_dynamic_model

## -----------------------------------------------------------------------------
parameter_set1

## -----------------------------------------------------------------------------
parameter_set1$dynamic_model <- bushplus_dynamic_model

## -----------------------------------------------------------------------------
parameter_set1$strain_parameter <- new_strain_parameter(
    n_CB = 1,
    values_CB = "bush",
    n_PB = 1,
    values_PB = "bush",
    n_SB = 1,
    values_SB = "bush",
    values_other = "bush",
    values_initial_state = "bush_anoxic_fig2ab"
)

## -----------------------------------------------------------------------------
parameter_set1$strain_parameter$CB

## -----------------------------------------------------------------------------
parameter_set1$strain_parameter$initial_state

## -----------------------------------------------------------------------------
new_initial_state(values = "bush_oxic_fig2cd")

## -----------------------------------------------------------------------------
new_CB_strain_parameter(values = "bush")

## -----------------------------------------------------------------------------
parameter_set1$sim_duration <- 2000

## -----------------------------------------------------------------------------
parameter_set1$sim_sample_interval <- 1

## -----------------------------------------------------------------------------
parameter_set1$log10a_series <- c(
  log10(parameter_set1$strain_parameter$a_O),
  log10(parameter_set1$strain_parameter$a_O)
)

## -----------------------------------------------------------------------------
parameter_set1$event_definition <- event_definition_1

## -----------------------------------------------------------------------------
parameter_set1$event_interval <- 10

## -----------------------------------------------------------------------------
parameter_set1$noise_sigma <- 0

## -----------------------------------------------------------------------------
parameter_set1$minimum_abundances <- rep(0, 3)
names(parameter_set1$minimum_abundances) <- c("CB", "PB", "SB")

## -----------------------------------------------------------------------------
sp <- new_strain_parameter(
    n_CB = 1,
    values_CB = "bush",
    n_PB = 1,
    values_PB = "bush",
    n_SB = 1,
    values_SB = "bush",
    values_other = "bush",
    values_initial_state = "bush_anoxic_fig2ab"
)
  
parameter_set1 <- new_runsim_parameter(
    dynamic_model = bushplus_dynamic_model,
    strain_parameter = sp,
    sim_duration = 2000,
    sim_sample_interval = 1,
    log10a_series = c(
        log10(sp$a_O),
        log10(sp$a_O)
    ),
    event_definition = event_definition_1,
    event_interval = 10,
    noise_sigma = 0,
    minimum_abundances = rep(0, 3)
)
names(parameter_set1$minimum_abundances) <- c("CB", "PB", "SB")
rm(sp)

## ---- error = TRUE------------------------------------------------------------
parameter <- new_runsim_parameter(
    dynamical_model = bushplus_dynamic_model
)

## ----eval = !file.exists(mdat("anoxic_start_sim_results.RDS"))----------------
#  anoxic_start_sim_results <- run_simulation(parameter_set1)

## ----eval = !file.exists(mdat("anoxic_start_sim_results.RDS")), echo = FALSE----
#  saveRDS(anoxic_start_sim_results, file = mdat("anoxic_start_sim_results.RDS"))

## ----eval = !file.exists(mdat("anoxic_start_sim_results.RDS"))----------------
#  anoxic_start_sim_results_2 <- run_simulation(anoxic_start_sim_results)

## ----echo = FALSE-------------------------------------------------------------
anoxic_start_sim_results <- readRDS(file = mdat("anoxic_start_sim_results.RDS"))

## -----------------------------------------------------------------------------
plot_dynamics(anoxic_start_sim_results)

## -----------------------------------------------------------------------------
parameter_set1$strain_parameter <- new_strain_parameter(values_initial_state = "bush_oxic_fig2cd")

## ----eval = !file.exists(mdat("oxic_start_sim_results.RDS"))------------------
#  oxic_start_sim_results <- run_simulation(parameter_set1)
#  saveRDS(oxic_start_sim_results, file = mdat("oxic_start_sim_results.RDS"))

## ----echo = FALSE-------------------------------------------------------------
oxic_start_sim_results <- readRDS(file = mdat("oxic_start_sim_results.RDS"))

## -----------------------------------------------------------------------------
plot_dynamics(oxic_start_sim_results)

## -----------------------------------------------------------------------------
parameter_set1$strain_parameter <- new_strain_parameter(
  n_CB = 3,
  n_PB = 3,
  n_SB = 3
)

## -----------------------------------------------------------------------------
parameter_set1$strain_parameter$CB

## -----------------------------------------------------------------------------
parameter_set1$strain_parameter$initial_state

## -----------------------------------------------------------------------------

parameter_set1$strain_parameter$initial_state["CB_1"] <- 5e3
parameter_set1$strain_parameter$initial_state["CB_2"] <- 1e3
parameter_set1$strain_parameter$initial_state["CB_3"] <- 0
parameter_set1$strain_parameter$initial_state["PB_1"] <- 1e7
parameter_set1$strain_parameter$initial_state["PB_2"] <- 1e6
parameter_set1$strain_parameter$initial_state["PB_3"] <- 1e5
parameter_set1$strain_parameter$initial_state["SB_1"] <- 1e7
parameter_set1$strain_parameter$initial_state["SB_2"] <- 1e6
parameter_set1$strain_parameter$initial_state["SB_3"] <- 1e5
# parameter$strain_parameter$initial_state["SO"] <- 300
# parameter$strain_parameter$initial_state["SR"] <- 300
# parameter$strain_parameter$initial_state["O"] <- 1e1
# parameter$strain_parameter$initial_state["P"] <- 1e1

## ----eval = !file.exists(mdat("multistrain3.RDS"))----------------------------
#  parameter_set1$initial_state <- parameter_set1$strain_parameter$initial_state
#  simulation_result3 <- run_simulation(parameter_set1)
#  saveRDS(simulation_result3, file = mdat("multistrain3.RDS"))

## -----------------------------------------------------------------------------
simulation_result3 <- readRDS(file = mdat("multistrain3.RDS"))
plot_dynamics(simulation_result3)

## ----sim_ss_CB_SB_PB1, eval = TRUE--------------------------------------------
ma <- rep(0, 3)
names(ma) <- c("CB", "PB", "SB")

parameter_set2 <- new_replication_ssfind_parameter(
  dynamic_model = bushplus_dynamic_model,
  strain_parameter = new_strain_parameter(
    n_CB = 1,
    n_PB = 1,
    n_SB = 1,
    values_initial_state = "bush_ssfig3"
  ),
  sim_duration = 50000,
  sim_sample_interval = 50000,
  event_definition = event_definition_1,
  event_interval = 50000,
  ss_expt = NA,
  noise_sigma = 0,
  minimum_abundances = ma
)

rm(ma)

## ----sim_ss_CB_SB_PB2, eval = !file.exists(mdat("ss_1strain.RDS"))------------
#  grid_num_a <- 100                               ## number of a_0 values
#  grid_num_N <- 2                                 ## number of N values
#  
#  initial_CBs <- 10^seq(0, 10, length=grid_num_N) ## sequence of N values
#  initial_PBs <- 1e8                              ## not varied
#  initial_SBs <- 1e8                              ## not varied
#  
#  a_Os <- 10^seq(-6, -2, length=grid_num_a)       ## sequence of a_0 values
#  
#  ## next line creates all possible combinations
#  expt <- expand.grid(N_CB = initial_CBs,
#                      N_PB = initial_PBs,
#                      N_SB = initial_SBs,
#                      a_O = a_Os)
#  
#  parameter_set2$ss_expt <- expt
#  
#  rm(grid_num_a, grid_num_N, initial_CBs, initial_PBs, initial_SBs, a_Os, expt)
#  
#  # next line runs the "experiment", calling various functions to do this.
#  sim_res <- run_replication_ssfind(parameter_set2)
#  
#  saveRDS(sim_res, file = mdat("ss_1strain.RDS"))

## ----echo = FALSE-------------------------------------------------------------
ss_1strain <- readRDS(file = mdat("ss_1strain.RDS"))

## -----------------------------------------------------------------------------
p1 <- ss_1strain$result %>%
  mutate(direction = ifelse(initial_N_CB == 1, "up", "down")) %>%
  select(a, direction,
         starts_with("CB"),
         starts_with("PB"),
         starts_with("SB"))  %>%
  gather(key = Species, value=Quantity, 3:ncol(.)) %>%
  ggplot() +
  geom_path(aes(x = a, y = log10(Quantity+1), col = Species, linetype = direction),
            size=1) +
  ylab(expression(Log[10](Abundance+1))) +
  xlab(expression(Log[10](Oxygen~diffusivity))) +
  ylim(0,10) +
  #theme(plot.title=element_text(size=10, hjust=0.5)) +
  labs(title="Organisms")
##ggsave("figures/CB_SB_PB.png", width = 3, height = 2)

p2 <- ss_1strain$result %>%
  mutate(direction = ifelse(initial_N_CB == 1, "up", "down")) %>%
  select(a, direction ,SO, SR, O, P) %>%
  gather(key = Species, value=Quantity, 3:ncol(.)) %>%
  ggplot() +
  geom_path(aes(x = a, y = log10(Quantity), col = Species, linetype = direction)) +
  labs(title="Substrates")


p1 / p2

## ----sim_ss_CB_SB_PB4, eval = !file.exists(mdat("ss_3strain.RDS"))------------
#  parameter_set2$strain_parameter <- new_strain_parameter(
#    n_CB = 3,
#    n_PB = 3,
#    n_SB = 3,
#    values_initial_state = "bush_ssfig3"
#  )
#  
#  ss_3strain <- run_replication_ssfind(parameter_set2)
#  saveRDS(ss_3strain, file = mdat("ss_3strain.RDS"))

## ----echo = FALSE-------------------------------------------------------------
ss_3strain <- readRDS(file = mdat("ss_3strain.RDS"))

## ----echo = FALSE-------------------------------------------------------------
p1 <- ss_3strain$result %>%
  mutate(direction = ifelse(initial_N_CB == 1, "up", "down")) %>%
  select(a, direction,
         starts_with("CB"),
         starts_with("PB"),
         starts_with("SB"))  %>%
  gather(key = Species, value=Quantity, 3:ncol(.)) %>%
  ggplot() +
  geom_path(aes(x = a, y = log10(Quantity+1), col = Species, linetype = direction),
            size=1) +
  ylab(expression(Log[10](Abundance+1))) +
  xlab(expression(Log[10](Oxygen~diffusivity))) +
  ylim(0,10) +
  #theme(plot.title=element_text(size=10, hjust=0.5)) +
  labs(title="Organisms")
##ggsave("figures/CB_SB_PB.png", width = 3, height = 2)

p2 <- ss_3strain$result %>%
  mutate(direction = ifelse(initial_N_CB == 1, "up", "down")) %>%
  select(a, direction ,SO, SR, O, P) %>%
  gather(key = Species, value=Quantity, 3:ncol(.)) %>%
  ggplot() +
  geom_path(aes(x = a, y = log10(Quantity), col = Species, linetype = direction)) +
  labs(title="Substrates")


p1 / p2

## ----temporal_ss_find, eval = !file.exists(mdat("temporal_ss_find.RDS"))------
#  log10a_series <- seq(-8, 0, length = 100)
#  wait_time <- 1e3 # time spent at each step
#  num_strains <- 3
#  
#  total_initial_abundances <- 10^5
#  
#  num_CB_strains <- num_strains
#  num_SB_strains <- num_strains
#  num_PB_strains <- num_strains
#  
#  sp <- new_strain_parameter(
#    n_CB = num_CB_strains,
#    n_PB = num_SB_strains,
#    n_SB = num_PB_strains,
#    values_initial_state = "bush_ssfig3"
#  )
#  
#  parameter <- new_runsim_parameter(
#    dynamic_model = bushplus_dynamic_model,
#    event_definition = event_definition_1,
#    event_interval = 1000,
#    noise_sigma = 0,
#    minimum_abundances = rep(1, 3),
#    strain_parameter = sp,
#    log10a_series = log10a_series
#  )
#  names(parameter$minimum_abundances) <- c("CB", "PB", "SB")
#  rm(sp)
#  parameter$sim_duration <- wait_time * length(parameter$log10a_series)
#  parameter$sim_sample_interval <- wait_time
#  parameter <- set_temporal_ssfind_initial_state(
#      parameter,
#      total_initial_abundances,
#      total_initial_abundances,
#      total_initial_abundances
#  )
#  
#  ## be careful, this could take a long time to run if parameters above are changed (the demonstration parameters are with very short wait time).
#  temporal_ss_find_result <- run_temporal_ssfind(parameter)
#  
#  saveRDS(temporal_ss_find_result, file = mdat("temporal_ss_find.RDS"))

## ----fig.height=4-------------------------------------------------------------
temporal_ss_find_result <- readRDS(file = mdat("temporal_ss_find.RDS"))


p1 <- temporal_ss_find_result %>%
  mutate(a = 10^a_O) %>%
  gather(species, quantity, 2:(ncol(.) - 2)) %>%
  mutate(log10_quantity = log10(quantity + 1)) %>%
  dplyr::filter(species == "O") %>%
  ggplot(aes(x = log10(a), y = log10_quantity, col = species)) +
  geom_path() +
  ylab("Log(Quantity)") +
  xlab("Oxygen diffusivity") +
  theme(legend.position="none") +
  geom_vline(xintercept = c(-8, 0), col = "grey", lwd = 3)
p1


## -----------------------------------------------------------------------------
get_stability_measures(ss_1strain)

## -----------------------------------------------------------------------------
get_stability_measures(ss_3strain)

## -----------------------------------------------------------------------------
get_stability_measures(temporal_ss_find_result)

